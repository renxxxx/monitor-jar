#!/bin/sh
java -classpath "./jre1.8.0_201" -jar ./main.jar